'use strict';

(function () {
  
  init();

  async function init() {
    DM_SETTINGS.generateSettingsMenu();
    bindEvents();
  }

  function bindEvents() {
    
  }

})();
