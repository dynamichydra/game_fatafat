'use strict';

(function () {
  
  init();

  function init() {
    $('#pageTitle').html('Rules');
    bindEvents();
  }

  function bindEvents() {
    
  }

})();