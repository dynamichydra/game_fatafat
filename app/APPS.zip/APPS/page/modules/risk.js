'use strict';

(function () {
  
  init();

  function init() {
    $('#pageTitle').html('Risk Disclosure Agreement');
    bindEvents();
  }

  function bindEvents() {
    
  }

})();